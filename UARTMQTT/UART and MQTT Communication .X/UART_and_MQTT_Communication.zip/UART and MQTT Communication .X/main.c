#include <xc.h>        // Include processor files - each processor file is guarded.
#include "mcc_generated_files/mcc.h"  // Include MCC-generated headers for setup
#include <stdio.h>     // Include stdio.h for printf support

void main(void) {
    // Initialize the device
    SYSTEM_Initialize();

    // Declare variables
    int ii = 0;        // Integer variable
    float value;       // Float variable

    // Enable global and peripheral interrupts
    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();

    // Main loop
    while (1) {
        // Increment ii
        ii++;

        // Reset ii to 0 if it reaches 100 or more
        if (ii >= 100) {
            ii = 0;
        }

        // Convert ii to float and divide by 10, storing as value
        value = (float)ii / 10.0;

        // Print formatted string to output
        printf("ii:%d;value:%.2f;\r", ii, value);

        // Delay for 1000 milliseconds (1 second)
        __delay_ms(1000);
    }
}
